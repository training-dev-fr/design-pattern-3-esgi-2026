import Email from "./FactoryItem/Email.js";
import Password from "./FactoryItem/Password.js";
import Select from "./FactoryItem/Select.js";
import Text from "./FactoryItem/Text.js";

export default class FormFactory {
    constructor(item) {
        switch (item.type) {
            case "text":
                return new Text(item);
            case "password":
                return new Password(item);
            case "email":
                return new Email(item);
            case "select":
                return new Select(item);
        }
    }
}