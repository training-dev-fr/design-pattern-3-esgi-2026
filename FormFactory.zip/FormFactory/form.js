import FormFactory from "./FormFactory.js";

async function loadData() {
    let result = await fetch('./dataset.json');
    let data = await result.json();
    return data;
}

function showForm(item) {
    let element = new FormFactory(item);
    document.querySelector('.form').appendChild(element.display());
    element.onChange((value) => {
        console.log(value);
    });

}

let data = null;

async function init() {
    data = await loadData();
    for(let element of data){
        showForm(element);
    }
}

init();